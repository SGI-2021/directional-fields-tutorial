function K = GaussCurvature(V,F,EV)

%Gaussian curvature as an angle defect
edge12 = V(F(:,2),:)-V(F(:,1),:);
edge23 = V(F(:,3),:)-V(F(:,2),:);
edge31 = V(F(:,1),:)-V(F(:,3),:);

edge12=edge12./normv(edge12);
edge23=edge23./normv(edge23);
edge31=edge31./normv(edge31);

angle312 = acos(dot(edge12, -edge31,2));
angle123 = acos(dot(edge23, -edge12,2));
angle231 = acos(dot(edge31, -edge23,2));

%Confidence check: angles add up to pi
angleError = max(abs(angle312+angle123+angle231)-pi)

%Computing Gaussian curvature by accumarray on the face indices
angleSum = accumarray(reshape(F, 3*length(F),1), [angle312;angle123;angle231]);
K = 2*pi - angleSum;

%Confidence check: Gaussian Curvature sums up to the (2pi*) Euler characteristic
eulerChar = length(V)-length(EV)+length(F);
angleDefectError = abs(sum(K)-2*pi*eulerChar)

end