clc
close all
clear all

dataFolder = ['..' filesep 'data'];

%change this for different meshes
filename = 'elephant';

[V,F, ~,~] = readObj([dataFolder filesep filename '.obj']);

[EV, EF, FE]=make_edge_list(V,F);


%%%%%%%%%%%%%%%%%%%%%%%%%%Copy-paste from Exercise #1: Compute normals and local bases%%%%%%%%%%%%%

N = cross(V(F(:,2),:) - V(F(:,1),:),V(F(:,3),:) - V(F(:,1),:),2);
At = normv(N)/2;
N = N./repmat(normv(N),1,3);

B1 = V(F(:,2),:)-V(F(:,1),:);
B1 = B1./repmat(normv(B1),1,3);

B2 = cross(N,B1);
B2 = B2./repmat(normv(B2),1,3);  %no real need to normalize; just for numerical stability

faceCenter = (V(F(:,1),:)+V(F(:,2),:)+V(F(:,3),:))/3;

averageEdgeLength = mean(normv(V(EV(:,1),:)-V(EV(:,2),:)),1);

K = GaussCurvature(V,F, EV);
eulerChar = length(V)-length(EV)+length(F);
if (eulerChar~=2)
    warning('Warning: the mesh either has boundary loops or high genus and the current implementation would yield unexpected results!');
end

%%%%%%%%%%%%%%%%%%%%%%%%%Section 1: Solving for the effort%%%%%%%%%%%%%%%%%

%user parameters - play with them (up to consistency...)
N=1;
presVertices = randi([1,length(V)], 2*N+3*eulerChar,1);
presIndices=zeros(length(V),1);
presIndices(presVertices)=[ones(2*N,1); 2*ones(eulerChar,1); -ones(2*eulerChar,1)]/N;

%Confidence check: prescribed indices add up correctly to the Euler
%characteristic.
indexPresError = sum(presIndices)-eulerChar

%copy-pasted d0 and W.
d0 = sparse(repmat((1:length(EV))', 1,2), EV, [-ones(length(EV),1), ones(length(EV),1)], length(EV), length(V));
primalEdgeLength = normv(V(EV(:,1),:)-V(EV(:,2),:));
mutualTriArea = At(abs(EF(:,1)))+At(abs(EF(:,2)));
W = spdiags(mutualTriArea./(3*primalEdgeLength), 0, length(EF), length(EF)); %the opposite from PowerFIels, since this is dual/primal!

%setting up the system and solving
lhs = d0'*W*d0;
rhs = (2*pi*N*presIndices-N*K);
psi = lhs\rhs;
effort = W*d0*psi;

%Confidence check: effort adds up.
effortError = max(abs(d0'*effort - (2*pi*N*presIndices-N*K)))

%%%%%%%%%%%%%%%%%%%%%%%Section 2: reconstructing the field%%%%%%%%%%%%%%

constFaces = [100];  %if you add more than one, the system will be solvable, but not have zero error.
constRawField = B1(constFaces,:);
freeFaces = setdiff((1:length(F))', constFaces);

%converting to power representation
constComplexField = complex(dot(constRawField, B1(constFaces,:),2), dot(constRawField, B2(constFaces,:),2));
constPowerField = constComplexField.^N;

%creating connection variables - incorporating the effort!
edgeVector = V(EV(:,1),:)-V(EV(:,2),:);
conjEleft = complex(dot(edgeVector, B1(abs(EF(:,1)),:),2), -dot(edgeVector, B2(abs(EF(:,1)),:),2)).^N; 
conjEright = complex(dot(edgeVector, B1(abs(EF(:,2)),:),2), -dot(edgeVector, B2(abs(EF(:,2)),:),2)).^N; 

%differential operators
d1T = sparse(repmat((1:length(EF))', 1,2), abs(EF(:,1:2)), [-conjEleft.*exp(complex(0,effort)), conjEright], length(EF), length(F));

%moving the constraints to the rhs
d1TFree = d1T(:, freeFaces);
d1TConst = d1T(:, constFaces);
rhs = -d1TFree'*d1TConst*constPowerField;
lhs = d1TFree'*W*d1TFree;

%solving the system
freePowerField = lhs\rhs;
fullPowerField=zeros(length(F),1);
fullPowerField(freeFaces) = freePowerField;
fullPowerField(constFaces) = constPowerField;

fieldFromEffortError = max(abs(lhs*freePowerField-rhs))

%%%%%%%%The same visualization procedure from excercise #1 (with possibility for more indices%%%%%%%

%getting the roots (as a single representator
fullComplexField = fullPowerField.^(1/N);
%normalizing field
fullComplexField=fullComplexField./abs(fullComplexField);

%visualizing result
posSings1 = find(N*presIndices==1);
posSings2 = find(N*presIndices==2);
negSings1 = find(N*presIndices==-1);

figure
hold on
patch('faces', F, 'vertices', V,  'faceColor', 'w', 'edgeColor', 'none'); axis equal; cameratoolbar;
for i=1:N
    %this generates all the roots by i*pi/N rotations from each the
    %original.
    currRawField = B1.*real(fullComplexField*exp(complex(0,2*i*pi/N)))+B2.*imag(fullComplexField*exp(complex(0,2*i*pi/N)));
    fieldSource = faceCenter;
    fieldTarget = faceCenter + averageEdgeLength*currRawField/3;
    PlotVectors(fieldSource, fieldTarget, 'b');
end
axis equal; cameratoolbar;
plot3(V(posSings1,1), V(posSings1,2), V(posSings1,3), '.g', 'MarkerSize', 30);
plot3(V(posSings2,1), V(posSings2,2), V(posSings2,3), '.y', 'MarkerSize', 30);
plot3(V(negSings1,1), V(negSings1,2), V(negSings1,3), '.r', 'MarkerSize', 30);
title('Singularity indices. Green is +1/N, red is -1/N');




