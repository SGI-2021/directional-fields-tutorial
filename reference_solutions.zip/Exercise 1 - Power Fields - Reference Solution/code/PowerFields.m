clc
close all
clear all

dataFolder = ['..' filesep 'data'];

%change this for different meshes
filename = 'bunny';

[V,F, ~,~] = readObj([dataFolder filesep filename '.obj']);

[EV, EF, FE]=make_edge_list(V,F);


%%%%%%%%%%%%%%%%%%%%%%%%%%Warmup exercise: Compute normals and local bases%%%%%%%%%%%%%

N = cross(V(F(:,2),:) - V(F(:,1),:),V(F(:,3),:) - V(F(:,1),:),2);
At = normv(N)/2;
N = N./repmat(normv(N),1,3);

B1 = V(F(:,2),:)-V(F(:,1),:);
B1 = B1./repmat(normv(B1),1,3);

B2 = cross(N,B1);
B2 = B2./repmat(normv(B2),1,3);  %no real need to normalize; just for numerical stability

faceCenter = (V(F(:,1),:)+V(F(:,2),:)+V(F(:,3),:))/3;

averageEdgeLength = mean(normv(V(EV(:,1),:)-V(EV(:,2),:)),1);

%visualize basis and normals
figure
hold on
patch('faces', F, 'vertices', V,  'faceColor', 'white', 'edgeColor', 'none'); axis equal; cameratoolbar;
title('Mesh Normals (red) and tangent basis (blue)');
axis equal; cameratoolbar;
NSource = faceCenter;
NTarget = faceCenter + averageEdgeLength*N/3;
PlotVectors(NSource, NTarget, 'r');
B1Source = faceCenter;
B1Target = faceCenter + averageEdgeLength*B1/3;
PlotVectors(B1Source, B1Target, 'b');
B2Source = faceCenter;
B2Target = faceCenter + averageEdgeLength*B2/3;
PlotVectors(B2Source, B2Target, 'b');


%%%%%%%%%%%%%%%%%%%%%%%%%%Section 1: Power-field interpolation%%%%%%%%%%%%%%%%%%%%%%%%%

N=4;
constFaces = [1;250];
constRawField = B1(constFaces,:);
freeFaces = setdiff((1:length(F))', constFaces);

%converting to power representation
constComplexField = complex(dot(constRawField, B1(constFaces,:),2), dot(constRawField, B2(constFaces,:),2));
constPowerField = constComplexField.^N;

%creating connection variables
edgeVector = V(EV(:,1),:)-V(EV(:,2),:);
conjEleft = complex(dot(edgeVector, B1(abs(EF(:,1)),:),2), -dot(edgeVector, B2(abs(EF(:,1)),:),2)).^N; 
conjEright = complex(dot(edgeVector, B1(abs(EF(:,2)),:),2), -dot(edgeVector, B2(abs(EF(:,2)),:),2)).^N; 

%differential operators
dchi = sparse(repmat((1:length(EF))', 1,2), abs(EF(:,1:2)), [-conjEleft, conjEright], length(EF), length(F));
primalEdgeLength = normv(V(EV(:,1),:)-V(EV(:,2),:));
mutualTriArea = At(abs(EF(:,1)))+At(abs(EF(:,2)));
W = spdiags(3*primalEdgeLength./mutualTriArea, 0, length(EF), length(EF));

%moving the constraints to the rhs
d1TFree = dchi(:, freeFaces);
d1TConst = dchi(:, constFaces);
rhs = -d1TFree'*d1TConst*constPowerField;
lhs = d1TFree'*W*d1TFree;

%solving the system
freePowerField = lhs\rhs;
fullPowerField=zeros(length(F),1);
fullPowerField(freeFaces) = freePowerField;
fullPowerField(constFaces) = constPowerField;

%getting the roots (as a single representator
fullComplexField = fullPowerField.^(1/N);
%normalizing field
fullComplexField=fullComplexField./abs(fullComplexField);

%visualizing result
freeFacesMask = zeros(length(F),1);
freeFacesMask(constFaces)=1;
figure
hold on
patch('faces', F, 'vertices', V,  'faceColor', 'flat', 'CData', freeFacesMask, 'edgeColor', 'none'); axis equal; cameratoolbar;
title('N-Field on mesh. In yellow: constrained faces');
for i=1:N
    %this generates all the roots by i*pi/N rotations from each the
    %original.
    currRawField = B1.*real(fullComplexField*exp(complex(0,2*i*pi/N)))+B2.*imag(fullComplexField*exp(complex(0,2*i*pi/N)));
    fieldSource = faceCenter;
    fieldTarget = faceCenter + averageEdgeLength*currRawField/3;
    PlotVectors(fieldSource, fieldTarget, 'g');
end











