
%%%%%%%%%%%%%%%Section 2: Principal matching and singularities%%%%%%%%%%%%%

%generating the basis cycles matrix d0^T
d0 = sparse(repmat((1:length(EV))', 1,2), EV, [-ones(length(EV),1), ones(length(EV),1)], length(EV), length(V));
eulerChar = length(V)-length(EV)+length(F);

K = GaussCurvature(V,F,EV);

%plotting Gaussian curvature
figure
hold on
patch('faces', F, 'vertices', V,  'faceColor', 'interp', 'CData', K); axis equal; cameratoolbar;
title('Gaussian Curvature');
axis equal; cameratoolbar;

%computing the effort of the cross field
complexEffort = (fullPowerField(abs(EF(:,2))).*conjEright)./(fullPowerField(abs(EF(:,1))).*conjEleft);
effort = angle(complexEffort);
indices = (d0'*effort + N*K)/(2*pi*N);

%confidence check: indices are integer
indicesIntegerError = max(abs(N*indices - round(N*indices)))
indices = round(N*indices)/N;

%Confidence check: indices add up to the Euler char
indicesSumError = sum(indices) - eulerChar

posSings = find(indices>0);
negSings = find(indices<0);

figure
hold on
patch('faces', F, 'vertices', V,  'faceColor', 'w', 'edgeColor', 'none'); axis equal; cameratoolbar;
for i=1:N
    %this generates all the roots by i*pi/N rotations from each the
    %original.
    currRawField = B1.*real(fullComplexField*exp(complex(0,2*i*pi/N)))+B2.*imag(fullComplexField*exp(complex(0,2*i*pi/N)));
    fieldSource = faceCenter;
    fieldTarget = faceCenter + averageEdgeLength*currRawField/3;
    PlotVectors(fieldSource, fieldTarget, 'b');
end
axis equal; cameratoolbar;
plot3(V(posSings,1), V(posSings,2), V(posSings,3), '.g', 'MarkerSize', 30);
plot3(V(negSings,1), V(negSings,2), V(negSings,3), '.r', 'MarkerSize', 30);
title('Singularity indices. Green is +1/N, red is -1/N');











